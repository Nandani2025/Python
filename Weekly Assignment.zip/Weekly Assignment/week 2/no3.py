student=int(input("total no of student"))
group=int(input("enter total no group" ))

group_num=student//group
remaning_student=student%group
print(f"there will be {group_num} group with {remaning_student} student leftout")

