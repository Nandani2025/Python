sweet=int(input("total no of sweets"))
student=int(input("total no of student"))

sweet_num=sweet//student
remaning_sweets=sweet%student

print(f"the no of sweet given will be {sweet_num} and {remaning_sweets} sweets remaning.")