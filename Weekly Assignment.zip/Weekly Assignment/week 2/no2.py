temp=int(input("Enter a temperature in Celsius"))
fahr=temp*(9/5)+32
print(f"{temp} is equivalent to {fahr}")   