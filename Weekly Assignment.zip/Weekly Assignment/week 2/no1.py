name=input("hello , what is your name")
print("hello",name, "do you want to meet me")