COMMON_PASSWORDS = ['password', 'letmein', 'sesame', 'hello', 'justinbieber']

while True:
    new_password = input("Enter a new password (8-12 characters): ")

    if len(new_password) < 8 or len(new_password) > 12:
        print("Error: Password must be between 8 and 12 characters.")
        continue

    if new_password.lower() in COMMON_PASSWORDS:
        print("Error: Password is too common. Choose a more secure password.")
        continue

    confirm_password = input("Re-enter your password: ")

    if new_password == confirm_password:
        print("Password successfully set!")
        break
    else:
        print("Error: Passwords do not match. Please try again.")

