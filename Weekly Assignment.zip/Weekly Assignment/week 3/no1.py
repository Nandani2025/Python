name= input("Enter your name")
if not name.strip():
  print("Hello,stranger!")
else:
  print(f"Hello,{name}!") 