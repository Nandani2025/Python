BAD_PASSWORDS = ['password', 'letmein', 'sesame', 'hello', 'justinbieber']

password1= input("Enter password(Password must be 8-12 characters long and not a common password)")
if not (8 <= len(password1) <= 12):
        print("Error")
for x in BAD_PASSWORDS:
    if x==password1:
        print("Error: Password is too common.")
    else:
        break
          
password2= input("Enter new password(Password must be 8-12 characters long and not a common password)")
if not (8 <= len(password2) <= 12):
        print("Error")
for x in BAD_PASSWORDS:
    if x==password2:
        print("Error: Password is too common.")
    else:
        print("you have a good password")

if password1 == password2:
        print("Error: Passwords do not match")
else:
        print("Password Set Successfully!")


