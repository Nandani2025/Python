password1= input("Enter a password")
password2= input("Enter new password")

if password1 == password2:
  print("error")
else:
  print("password successful")
