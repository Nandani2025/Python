password= input("Enter password (8-12 characters)")

if 8<= len(password) <=12:
  print("password")
else:
  print("your password must be between 8 and 12") 

password1=input("enter a nwe password")
if 8<= len(password1) <=12:
    print("password1")
else:
    print("password must be between 8 and 12")

if password==password1:
    print("error")
else:
   print("your passsword")       


