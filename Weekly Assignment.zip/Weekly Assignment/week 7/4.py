def letter_count(message):
    message = message.lower()
    count_dict = {}
    for char in message:
        if char.isalpha():  # Check if the character is a letter
            if char in count_dict:
                count_dict[char] += 1
            else:
                count_dict[char] = 1
    sorted_list = list(count_dict.items())
    sorted_list.sort(key=lambda x: x[1], reverse=True)
    return sorted_list[:6]

user_message = input("Enter the encrypted message: ")
top_letters = letter_count(user_message)
print("The six most common letters are:")
for letter, count in top_letters:
    print(f"'{letter}': {count} times")
