def union_of_characters(str1, str2):
    return sorted(set(str1) | set(str2))
def common_characters(str1, str2):
    return sorted(set(str1) & set(str2))
def unique_to_each_string(str1, str2):
    return sorted(set(str1) ^ set(str2))
# Taking inputs from the user
first_string = input("Enter the first word: ")
second_string = input("Enter the second word: ")
# Output the results
print(f"Characters in either word: {union_of_characters(first_string, second_string)}")
print(f"Characters in both words: {common_characters(first_string, second_string)}")
print(f"Characters unique to each word: {unique_to_each_string(first_string, second_string)}")
