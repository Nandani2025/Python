capitals = {}
while True:
    capital_city = input("Enter the name of a country (or 'exit' to quit): ").strip()
    if capital_city.lower() == 'exit':
        print("Program is exiting.")
        break
    capital_city_lower = capital_city.lower()
    if capital_city_lower in capitals:
        print(f"The capital of {capital_city} is {capitals[capital_city_lower]}.")
    else:
        capital_name = input(f"I don't know the capital of {capital_city}. Please enter it: ").strip()
        capitals[capital_city_lower] = capital_name
        print(f"Thank you! The capital of {capital_city} is now recorded as {capital_name}.")




