def get_sorted_unique_characters(text):
    unique_chars = {character for character in text if character.isalpha()}
    # Return a sorted list of unique characters
    return sorted(unique_chars)

if __name__ == "__main__":
    user_text = input("Enter any string: ")
    result = get_sorted_unique_characters(user_text)
    print(f"Sorted unique characters: {result}")