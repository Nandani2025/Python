if __name__ == "__main__":
    name = input("Enter your name: ").strip()
    formatted_name = name.upper()
    print(f"Hello, {formatted_name}!")