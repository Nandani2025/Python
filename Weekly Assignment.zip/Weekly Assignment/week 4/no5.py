def convert_celsius_to_fahrenheit(celsius):
    return celsius * 9/5 + 32

def convert_fahrenheit_to_celsius(fahrenheit):
    return (fahrenheit - 32) * 5/9

if __name__ == "__main__":
    celsius = float(input("Please enter the temperature in Celsius: "))
    fahrenheit = convert_celsius_to_fahrenheit(celsius)

    print(f"{celsius}C is equivalent to {fahrenheit:.2f}F")

    fahrenheit = float(input("Please enter the temperature in Fahrenheit: "))
    celsius = convert_fahrenheit_to_celsius(fahrenheit)

    print(f"{fahrenheit}°F is equivalent to {celsius:.2f}°C")

