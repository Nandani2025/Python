def count_case(string):
    upper = sum(1 for char in string if char.isupper())
    lower = sum(1 for char in string if char.islower())
    return upper, lower


if __name__ == "__main__":
    string = input("Enter a string: ")
    uppercase, lowercase = count_case(string)
    print(f"Uppercase letters: {uppercase}, Lowercase letters: {lowercase}")
