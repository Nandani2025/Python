if __name__ == "__main__":
    temperatures = []

    for _ in range(6):
        temp_input = input("Enter temperature (e.g., 25C): ").strip()
        if temp_input[-1].upper() == 'C':
            temperatures.append(float(temp_input[:-1]))
        else:
            print("Invalid input. Try again.")

    if temperatures:
        print(f"Max: {max(temperatures):.2f}C, Min: {min(temperatures):.2f}C, Mean: {sum(temperatures)/len(temperatures):.2f}C")
    else:
        print("No valid temperatures entered.")

       