import random
import string

# 1. Convert a positive integer to binary (using built-in functionality)
def convert_to_bin(number):
    """Converts a positive integer to binary representation."""
    if number > 0:
        return bin(number)[2:]
    else:
        return "Please provide a positive whole number."

# 2. Find factors of a positive number
def get_factors(number):
    """Returns a list of factors of the given number."""
    if number <= 0:
        return "Please enter a positive integer."
    return [i for i in range(1, number + 1) if number % i == 0]

# 3. Check if a number is prime
def check_prime(value):
    """Checks if the given value is a prime number."""
    if value <= 1:
        return False
    for i in range(2, int(value ** 0.5) + 1):
        if value % i == 0:
            return False
    return True

# 4. Simple encryption: remove spaces and reverse the string
def encrypt_message(text):
    """Encrypts the given text by removing spaces and reversing it."""
    return text.replace(" ", "")[::-1]

# 5. Encrypt with random spacing
def random_spacing_encrypt(text):
    """Encrypts the given text by inserting it into random characters at a random interval."""
    gap = random.randint(2, 20)
    random_chars = ''.join(random.choices(string.ascii_lowercase, k=len(text) * gap))
    encrypted_text = ''.join([random_chars[i*gap:(i*gap) + gap - 1] + char for i, char in enumerate(text)])
    return encrypted_text + random_chars[len(encrypted_text):], gap

# 6. Decrypt a spaced message given the interval
def random_spacing_decrypt(encrypted_text, gap):
    """Decrypts a message with random spacing using the provided interval."""
    return encrypted_text[gap-1::gap]

# Testing the functions
if __name__ == "__main__":
    # Binary conversion
    print("Binary of 10:", convert_to_bin(10))

    # Factors
    print("Factors of 12:", get_factors(12))

    # Prime check
    print("Is 13 prime?:", check_prime(13))

    # Simple encryption
    text = "hello world"
    print("Simple encryption:", encrypt_message(text))

    # Random spacing encryption
    encrypted_text, gap = random_spacing_encrypt(text)
    print(f"Random spacing encryption: {encrypted_text}, Gap: {gap:.2f}")

    # Decrypting spaced message
    decrypted_text = random_spacing_decrypt(encrypted_text, gap)
    print("Decrypted text:", decrypted_text)
   


