# simple_encryption.py
def reverse_and_remove_spaces(text):
    return text.replace(" ", "")[::-1]

# Test reverse_and_remove_spaces
if __name__ == "__main__":
    input_text = input("Enter a message: ")
    print(f"Encrypted message: {reverse_and_remove_spaces(input_text)}")
