# binary_representation.py
def convert_to_binary(value):
    return bin(value)[2:]

# Test convert_to_binary
if __name__ == "__main__":
    positive_number = int(input("Please enter a positive integer: "))
    print(f"Binary form: {convert_to_binary(positive_number)}")

    
