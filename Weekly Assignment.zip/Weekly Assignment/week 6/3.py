# prime_check.py
def check_prime(value):
    if value <= 1:
        return False
    for i in range(2, int(value**0.5) + 1):
        if value % i == 0:
            return False
    return True

# Test check_prime
if __name__ == "__main__":
    user_input = int(input("Enter an integer: "))
    print(f"Is prime: {check_prime(user_input)}")