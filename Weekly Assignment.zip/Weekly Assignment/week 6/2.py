# integer_factors.py
def get_factors(value):
    return [i for i in range(1, value + 1) if value % i == 0]

# Test get_factors
if __name__ == "__main__":
    input_number = int(input("Enter an integer: "))
    print(f"Factors: {get_factors(input_number)}")