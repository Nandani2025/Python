# interval_decryption.py
def decrypt_at_interval(encrypted_text, space):
    return encrypted_text[::space]

# Test decrypt_at_interval
if __name__ == "__main__":
    encrypted_text = input("Enter the encrypted message: ")
    space = int(input("Enter the interval: "))
    print(f"Decrypted message: {decrypt_at_interval(encrypted_text, space)}")
