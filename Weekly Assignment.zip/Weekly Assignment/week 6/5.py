# interval_encryption.py
import random
import string

def encrypt_with_interval(input_string):
    gap = random.randint(2, 20)
    encrypted_text = ""
    random_chars = lambda: random.choice(string.ascii_lowercase)
    for char in input_string:
        encrypted_text += char + "".join(random_chars() for _ in range(gap - 1))
    return encrypted_text, gap

# Test encrypt_with_interval
if __name__ == "__main__":
    user_message = input("Enter a message: ").replace(" ", "")
    encrypted_text, gap = encrypt_with_interval(user_message)
    print(f"Encrypted message: {encrypted_text}")
    print(f"Interval: {gap}")
