import random  # Importing the random module for selecting random responses and agents.
# User name input
name = input("Enter your name: ")  # Prompt user for their name.
print(f"Welcome {name} to Chatbot. You can ask anything about our college.")  # Welcome message for the user.

# Dictionary for chatbot responses
responses = {
    'name': ['The name of the college is The University of Poppleton'],
    'hyy': ['Hello, How can I help you?'],
    'principal': ['The name of our Principal is Dr. Laurie Taylor.'],
    'admission': [
        'The admission will start from the first of September. For more details, contact us or visit our website www.UniversityofPoppleton.com'
    ],  # Admission-related information.
    'location': ['Our college is located in Yorkshire, UK'],
    'facilities': [
        'We have various facilities such as sports, cafe, library, VR room, gym, auditorium, research labs, student lounge, computer labs, career counseling center, music rooms, theater, and student health center.'
    ],  # Facilities available.
    'courses': [
        'We offer undergraduate and postgraduate courses in fields like Computer Science.'
    ],  # Courses information.
    'events': [
        'We host various events throughout the year, such as academic conferences, cultural festivals, sports tournaments, and career fairs. Stay updated by visiting our events page.'
    ],  # Event information.
    'campus life': [
        'Our campus offers a vibrant life with clubs, student organizations, sports teams, and cultural societies. It’s a great place to build memories and friendships.'
    ],  # Campus life info.
    'research': [
        'We have a thriving research community focused on cutting-edge projects in fields such as Artificial Intelligence, Robotics, Biotechnology, and Environmental Studies.'
    ],  # Research opportunities.
    'noreply': [
        'Sorry, I am not trained for this.',
        'I don’t have an answer for this.',
        'I am unable to respond to that request.'
    ]
}

# Randomly assign an agent
agents = ['Nikki', 'Anjali', 'Jimmy', 'Trigger', 'Fukra', 'Nandu']  # List of chatbot agent names.
user_agent = random.choice(agents)
print(f"Hello, I am your agent {user_agent}")

# Create or open a chat log file
log_file_name = f"{name}_chat_log.txt"
with open(log_file_name, "w") as log_file:
    log_file.write(f"Chat Session with Agent {user_agent}\n")
    log_file.write(f"User: {name}\n")
    log_file.write("--------------------------------------------------\n")

    # Chatbot loop
    while True:  # Start an infinite loop for chatbot interaction.
        choice = input("Ask Chatbot: ").lower()  # Convert input to lowercase to make it case-insensitive.
        log_file.write(f"User: {choice}\n")

        if choice == 'okay bye':  # If user types 'okay bye', exit the loop.
            farewell = "Bye! It was nice talking with you."
            print(farewell)
            log_file.write(f"Agent: {farewell}\n")
            break  # Exit the loop.

        found = False  # Flag to track if a matching response is found.
        for key in responses.keys():
            if key in choice:  # Check if the user's input contains any of the keys.
                reply = random.choice(responses[key])  # Randomly select a response.
                print(reply)
                log_file.write(f"Agent: {reply}\n")
                found = True
                break  # Exit the loop once a response is found.

        if not found:  # If no matching key is found, provide a default "no reply" response.
            noreply = random.choice(responses['noreply'])
            print(noreply)
            log_file.write(f"Agent: {noreply}\n")

print(f"Chat session logged in '{log_file_name}'.")
